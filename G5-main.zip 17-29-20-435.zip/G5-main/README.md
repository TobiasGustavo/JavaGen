# G5
<h2>
Vamos Falar Sobre as Vacinas do Covid-19
</h2>
  O projeto "Vamos falar sobre as vacinas” do Covid-19, é um projeto que visa educar a população brasileira, usuárias do Sistema Único de Saúde, por meio do uso de um software 
informativo, sobre os aspectos das vacinas utilizadas para a prevenção do Covid-19.
  Decidimos explorar mais as opções que o JOptionPane pode oferecer, com isso conseguimos usar imagens e textos como referência, também usamos heranças e um pouquinho
 de polimorfismo. O objetivo do projeto é ser um folheto informativo sobre o que são vírus, o covid e informações sobre as vacinas e seus fabricantes, além de dicas de prevenção.
 
 ![G5Dev](https://user-images.githubusercontent.com/19335381/137657955-45e5820d-82ac-4375-9d3a-7dfe6ba802a7.jpg)
<h2>
Aqui fica o nosso diagrama:
</h2>

![diagrama](https://user-images.githubusercontent.com/19335381/137734982-af400812-5728-4094-8068-9dd4f010fb1c.png)


<h1>
  Esse projeto foi feito por: 
</h1>
<br>
    Gustavo Sousa Martins 
    <br>
	  Mabile 			
    <br>
    Nathália
    <br>
		Rafael Edgar Rodrigues
    <br>
		Tobias Gustavo Soares 
<h3>
Toda a documentação está aqui:
</h3>
https://docs.google.com/document/d/1Vpm9VpvzLPXgCxmfsvBXaA0NRcK3dJWmlNckr8MQNfE/edit?usp=sharing
<h3>
Apresentação:
</h3>
https://prezi.com/view/5ASLav3OdD9vngiyeqgd/
